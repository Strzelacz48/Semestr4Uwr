import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class Zad1Testy {
    Car car = mock(Car.class);
    @Test
    public void arbitrary_test(){
        assertEquals(2, 1+1);
    }
    @Test
}
