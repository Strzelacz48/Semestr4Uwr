public class GenericDao {
    public void save()
    {
        System.out.println("zapisalem do bazy");
    }

    
}
