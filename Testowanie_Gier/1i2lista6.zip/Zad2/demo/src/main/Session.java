public class Session {
    GenericDao genericDao;
    private bool start_session()
    {
        if(true)
        {
            System.out.println("started session");
            return true;
        }
        else
        {
            return false;
        }
    }
    private bool transaction()
    {
        if(true)
        {
            System.out.println("started transaction");
            return true;
        }
        else
        {
            return false;
        }
    }
    private bool commit()
    {
        if(true)
        {
            System.out.println("commited");
            return true;
        }
        else
        {
            return false;
        }
    }
    private bool end_session()
    {
        if(true)
        {
            System.out.println("ended session");
            return true;
        }
        else
        {
            return false;
        }
    }
    public open()
    {
        if(!start_session())
        {
            throw("SessionOpenException");
        }
        if(!transaction())
        {
            throw("SessionOpenException");
        }
        genericDao.save();
        commit();
        end_session();
    }
    
}
